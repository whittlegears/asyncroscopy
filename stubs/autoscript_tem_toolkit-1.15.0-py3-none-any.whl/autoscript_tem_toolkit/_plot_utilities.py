import numpy
from typing import Optional

from autoscript_tem_microscope_client.structures import AdornedImage, AdornedSpectrum, AdornedImageMetadata


def get_image_label(image: AdornedImage) -> Optional[str]:
    """
    Creates a label for the image based on its metadata.
    """
    detector_name = _get_detector_name(image.metadata)

    if detector_name is not None:
        stem_segment = _get_custom_property_value(image.metadata, "StemSegment")

        if stem_segment is not None:
            return f"{detector_name}.{stem_segment}"
        else:
            return detector_name


def get_spectrum_label(spectrum: AdornedSpectrum) -> Optional[str]:
    """
    Creates a label for the spectrum based on its metadata.
    """
    return _get_detector_name(spectrum.metadata)


def get_spectrum_values(spectrum: AdornedSpectrum) -> (numpy.ndarray, numpy.ndarray):
    """
    Returns scaled and offset-ed energy bin values and primary electron counts.
    Intensity values are replaced with defaults if not found, spectrum values raise an error if not found.
    """
    intensity_offset, intensity_scale, spectrum_offset, spectrum_dispersion = _get_spectrum_properties(spectrum.metadata)

    # Convert raw pixel counts to primary electron counts
    scaled_spectrum = (spectrum.data * intensity_scale) + intensity_offset
    # Calculate energy bin values
    energies = (numpy.arange(len(scaled_spectrum)) * spectrum_dispersion) + spectrum_offset

    return energies, scaled_spectrum


def _get_spectrum_properties(metadata: AdornedImageMetadata) -> (float, float, float, float):
    return _get_intensity_spectrum_properties(metadata) + _get_energy_spectrum_properties(metadata)


def _get_intensity_spectrum_properties(metadata: AdornedImageMetadata) -> (float, float):
    try:
        intensity_offset = metadata.binary_result.intensity_offset
        intensity_scale = metadata.binary_result.intensity_scale
    except AttributeError:
        intensity_offset = None
        intensity_scale = None

    if intensity_offset is None:
        intensity_offset = 0
    if intensity_scale is None:
        intensity_scale = 1

    return intensity_offset, intensity_scale


def _get_energy_spectrum_properties(metadata: AdornedImageMetadata) -> (float, float):
    detector_name = _get_detector_name(metadata)

    if detector_name is None:
        raise ValueError("Spectrum metadata is missing detector name.")

    spectrum_offset = None
    spectrum_dispersion = None

    if metadata.analytical_detectors is not None:
        analytical_detector = next((a for a in metadata.analytical_detectors if detector_name in a.detector_name), None)

        if analytical_detector is not None:
            # Try checking the analytical detector metadata
            spectrum_offset = analytical_detector.offset_energy
            spectrum_dispersion = analytical_detector.dispersion

    # If it fails, check custom properties
    try:
        if spectrum_offset is None:
            spectrum_offset = float(_get_custom_property_value(metadata, f"Detectors[{detector_name}].SpectrumOffsetEnergy"))
        if spectrum_dispersion is None:
            spectrum_dispersion = float(_get_custom_property_value(metadata, f"Detectors[{detector_name}].SpectrumDispersion"))
    except TypeError:
        pass

    if spectrum_offset is None or spectrum_dispersion is None:
        raise ValueError("Spectrum metadata is missing dispersion or offset.")

    return spectrum_offset, spectrum_dispersion


def _get_custom_property_value(metadata: AdornedImageMetadata, custom_property_name: str) -> Optional[str]:
    try:
        custom_property_group = next((p for p in metadata.custom_properties if p.scope == "" or p.scope is None), None)
        custom_property = next((c for c in custom_property_group.properties if c.name == custom_property_name), None)
        return custom_property.value
    except (AttributeError, TypeError):
        pass


def _get_detector_name(metadata: AdornedImageMetadata) -> Optional[str]:
    try:
        detector_name = metadata.binary_result.detector
    except AttributeError:
        detector_name = None

    if detector_name is None:
        return _get_custom_property_value(metadata, "DetectorCommercialName")
    else:
        return detector_name
