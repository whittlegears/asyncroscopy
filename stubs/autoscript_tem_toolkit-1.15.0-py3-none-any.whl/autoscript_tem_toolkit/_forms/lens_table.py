from typing import Callable, TypeVar, List

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QPushButton, QHBoxLayout, QMessageBox, QGridLayout, QFrame, QVBoxLayout

from autoscript_tem_toolkit._forms._simple_inputs.number_inputs import FloatInput
from autoscript_tem_toolkit._forms._text_label import TextLabel
from autoscript_tem_toolkit._forms.enums import FontColor

T = TypeVar('T')

class LensTable(QWidget):
    def __init__(self, microscope, precision):
        super().__init__()
        self.microscope = microscope
        self.precision = precision
        lenses_names = microscope.optics.lenses.get_available()
        lenses = []
        for lens_name in lenses_names:
            lens = microscope.optics.lenses.get_lens(lens_name)
            lenses.append(lens)

        self._layout = QGridLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)

        def button_setter(lens, input, raw_input):
            def setter():
                try:
                    value = round(lens.value, self.precision)
                    raw_value = round(lens.value_raw, self.precision)
                    if input.get_value() != value:
                        lens.value = input.get_value()
                    elif raw_input.get_value() != raw_value:
                        lens.value_raw = raw_input.get_value()
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))
                finally:
                    input.set_value(round(lens.value, self.precision))
                    raw_input.set_value(round(lens.value_raw, self.precision))
            return setter

        def button_getter(lens, input, raw_input):
            def getter():
                try:
                    input.set_value(round(lens.value, self.precision))
                    raw_input.set_value(round(lens.value_raw, self.precision))
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))
            return getter

        i = 0
        self._layout.addWidget(TextLabel("Lens"), 0, 0)
        self._layout.addWidget(TextLabel("min"), 0, 1)
        self._layout.addWidget(TextLabel("Raw value"), 0, 2)
        self._layout.addWidget(TextLabel("max"), 0, 3)
        self._layout.addWidget(TextLabel("Value"), 0, 5)

        lens_x_available = False
        for lens in lenses:
            i += 1
            if lens.name == "X":
                lens_x_available = True
                continue
            label = TextLabel(lens.name)

            lower_limit = TextLabel(str(round(lens.limits_raw.min, self.precision)), font_color=FontColor.FADED)
            upper_limit = TextLabel(str(round(lens.limits_raw.max, self.precision)), font_color=FontColor.FADED)

            input = FloatInput(default_value=round(lens.value, self.precision))
            input.setFixedWidth(150)
            raw_input = FloatInput(default_value=round(lens.value_raw, self.precision))
            raw_input.setFixedWidth(150)
            setter_button = QPushButton("Set")
            setter_button.clicked.connect(button_setter(lens, input, raw_input))
            setter_button.setFixedWidth(40)
            getter_button = QPushButton("Get")
            getter_button.clicked.connect(button_getter(lens, input, raw_input))
            getter_button.setFixedWidth(40)

            self._layout.addWidget(label, i, 0)
            self._layout.addWidget(lower_limit, i, 1)
            self._layout.addWidget(raw_input, i, 2)
            self._layout.addWidget(upper_limit, i, 3)
            self._layout.addWidget(input, i, 5)
            self._layout.addWidget(setter_button, i, 6)
            self._layout.addWidget(getter_button, i, 7)

        if lens_x_available:
            i += 1
            self.add_lens_x(i,)


        # Add line separating raw value (and it's limits) from value
        line = QFrame()
        line.setFixedWidth(2)
        line.setStyleSheet("background-color: #888888;")
        layout = QVBoxLayout()
        layout.setContentsMargins(3, 0, 3, 0)
        layout.addWidget(line)
        self._layout.addLayout(layout, 0, 4, -1, 1)

    # Special case for a special lens
    def add_lens_x(self, index):

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.lineWidth = 2
        line.setStyleSheet("background-color: #888888;")
        layout = QHBoxLayout()
        layout.setContentsMargins(3, 0, 3, 0)
        layout.addWidget(line)
        self._layout.addLayout(layout, index, 0, 1, -1)

        index += 1

        self._layout.addWidget(TextLabel("Lens"), index, 0)
        self._layout.addWidget(TextLabel("min"), index, 1)
        self._layout.addWidget(TextLabel("Alignment preset raw value"), index, 2)
        self._layout.addWidget(TextLabel("max"), index, 3)
        self._layout.addWidget(TextLabel("Value"), index, 5)

        index += 1

        x_lens = self.microscope.optics.lenses.get_lens("X")
        x_label = TextLabel(x_lens.name)
        x_lower_limit = TextLabel(str(round(self.microscope.optics.lenses.alignments.x.preset_raw.limits.min, self.precision)),
                                  font_color=FontColor.FADED)
        x_upper_limit = TextLabel(str(round(self.microscope.optics.lenses.alignments.x.preset_raw.limits.max, self.precision)),
                                  font_color=FontColor.FADED)

        x_input = FloatInput(default_value=round(x_lens.value, self.precision))
        x_raw_input = FloatInput(default_value=round(self.microscope.optics.lenses.alignments.x.preset_raw.value, self.precision))

        def x_getter():
            x_input.set_value(round(x_lens.value, self.precision))
            x_raw_input.set_value(round(self.microscope.optics.lenses.alignments.x.preset_raw.value, self.precision))

        def x_setter():
            try:
                x_lens.value = x_input.get_value()
            except Exception as e:
                x_input.set_value(round(x_lens.value, self.precision))
                x_raw_input.set_value(round(self.microscope.optics.lenses.alignments.x.preset_raw.value, self.precision))
                QMessageBox.critical(self, "Error", str(e))

        x_setter_button = QPushButton("Set")
        x_setter_button.clicked.connect(x_setter)
        x_setter_button.setFixedWidth(40)
        x_getter_button = QPushButton("Get")
        x_getter_button.clicked.connect(x_getter)
        x_getter_button.setFixedWidth(40)

        self._layout.addWidget(x_label, index, 0)
        self._layout.addWidget(x_lower_limit, index, 1)
        self._layout.addWidget(x_raw_input, index, 2)
        self._layout.addWidget(x_upper_limit, index, 3)
        self._layout.addWidget(x_input, index, 5)
        self._layout.addWidget(x_setter_button, index, 6)
        self._layout.addWidget(x_getter_button, index, 7)

