from enum import Enum
from typing import TypeVar


class FontColor(Enum):
    NORMAL = "black"
    FADED = "gray"
    WARNING = "red"


class FontSize(Enum):
    SMALL = 8
    NORMAL = 10
    BIG = 12
