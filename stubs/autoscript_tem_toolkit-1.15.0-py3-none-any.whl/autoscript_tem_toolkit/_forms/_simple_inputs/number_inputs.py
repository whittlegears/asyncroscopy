from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QDoubleSpinBox, QSpinBox, QLineEdit

from autoscript_tem_toolkit._forms._text_label import TextLabel
from autoscript_tem_toolkit._forms.enums import FontSize, FontColor


class FloatInput(QWidget):
    def __init__(self, label_text: str = None, description: str = None, default_value: float = 0.0,):
        super().__init__()
        _layout = QVBoxLayout(self)
        _layout.setContentsMargins(0, 0, 0, 0)

        if label_text is not None:
            self.label = QLabel(label_text)
            _layout.addWidget(self.label)

        self._input = QLineEdit()
        self._input.setText(str(default_value))

        _layout.addWidget(self. _input)

        if description is not None:
            _layout.addWidget(TextLabel(description, FontSize.SMALL, FontColor.FADED))

        self.setLayout(_layout)

    def get_value(self):
        value = self._input.text()
        if value == "None" or value == "none":
            return None
        return float(self._input.text())

    def set_value(self, value):
        self._input.setText(str(value))


class IntegerInput(QWidget):
    def __init__(self, label_text: str = None, description: str = None, default_value: int = 0,
                 minimum: int = 0, maximum: int = 1000000, step: int = 1, special_value_text: str = None):
        super().__init__()
        _layout = QVBoxLayout(self)
        _layout.setContentsMargins(0, 0, 0, 0)

        if label_text is not None:
            self.label = QLabel(label_text)
            _layout.addWidget(self.label)

        self._spin_box = QSpinBox()
        self._spin_box.setValue(default_value)
        self._spin_box.setMinimum(minimum)
        self._spin_box.setMaximum(maximum)
        self._spin_box.setSingleStep(step)

        if special_value_text is not None:
            self._spin_box.setSpecialValueText(special_value_text)

        _layout.addWidget(self. _spin_box)

        if description is not None:
            _layout.addWidget(TextLabel(description, FontSize.SMALL, FontColor.FADED))

        self.setLayout(_layout)

    def get_value(self):
        return self._spin_box.value()
