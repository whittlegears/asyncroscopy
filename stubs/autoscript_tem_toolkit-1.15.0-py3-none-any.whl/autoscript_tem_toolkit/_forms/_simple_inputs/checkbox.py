from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QCheckBox

from autoscript_tem_toolkit._forms._text_label import TextLabel
from autoscript_tem_toolkit._forms.enums import FontSize, FontColor


class CheckBox(QWidget):
    def __init__(self, label_text: str, default_value: Optional[bool] = None, description: str = ""):
        super().__init__()
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._checkbox = QCheckBox(label_text)
        self._checkbox.setTristate(True)

        if default_value:
            self._checkbox.setChecked(True)

        self._layout.addWidget(self._checkbox)

        if description != "":
            self._layout.addWidget(TextLabel(description, FontSize.SMALL, FontColor.FADED))
        self.setLayout(self._layout)

        self.setLayout(self._layout)

    def get_state(self) -> Optional[bool]:
        if self._checkbox.checkState() == Qt.CheckState.PartiallyChecked:
            return False
        elif self._checkbox.checkState() == Qt.CheckState.Checked:
            return True
        else:
            return None
