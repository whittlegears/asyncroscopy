from typing import List, TypeVar

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QComboBox, QListWidget, QHBoxLayout, QListWidgetItem, QPushButton

from autoscript_tem_toolkit._forms._text_label import  TextLabel
from autoscript_tem_toolkit._forms.enums import FontSize, FontColor

T = TypeVar('T')

class ComboBox(QWidget):
    def __init__(self, label_text: str, options: List[T], is_editable: bool = False, description: str = ""):
        super().__init__()
        _layout = QVBoxLayout(self)
        _layout.setContentsMargins(0, 0, 0, 0)

        if label_text != "":
            _layout.addWidget(TextLabel(label_text))

        self._combobox = QComboBox()

        for option in options:
            self._combobox.addItem(str(option))

        if is_editable:
            self._combobox.setEditable(True)

        _layout.addWidget(self._combobox)

        if description != "":
            _layout.addWidget(TextLabel(description, FontSize.SMALL, FontColor.FADED))
        self.setLayout(_layout)

    def get_value(self):
        return self._combobox.currentText()

    def change_options(self, options: List[T]):
        self._combobox.clear()
        for option in options:
            self._combobox.addItem(str(option))

    def hook_change_function(self, function):
        self._combobox.currentTextChanged.connect(function)


class ListComboBox(QWidget):
    def __init__(self, label_text: str, options: List[T], is_editable: bool = False, description: str = ""):
        super().__init__()
        _main_layout = QVBoxLayout(self)
        _main_layout.setContentsMargins(0, 0, 0, 0)

        if label_text != "":
            _main_layout.addWidget(TextLabel(label_text))

        self._listbox = QListWidget()
        _main_layout.addWidget(self._listbox)

        self._combobox = QComboBox()

        for option in options:
            self._combobox.addItem(str(option), userData=option)

        if is_editable:
            self._combobox.setEditable(True)

        _main_layout.addWidget(self._combobox)

        button_layout = QHBoxLayout()

        def add():
            if self._combobox.currentText():
                item = QListWidgetItem(self._combobox.currentText())
                item.setData(Qt.UserRole, self._combobox.currentData())
                self._listbox.addItem(item)

        add_button = QPushButton("Add")
        add_button.clicked.connect(add)
        button_layout.addWidget(add_button)

        def remove_selected():
            to_remove = self._listbox.selectedItems()

            if to_remove:
                for item in to_remove:
                    self._listbox.takeItem(self._listbox.row(item))

        remove_button = QPushButton("Remove")
        remove_button.clicked.connect(remove_selected)
        button_layout.addWidget(remove_button)
        _main_layout.addLayout(button_layout)

        if description != "":
            _main_layout.addWidget(TextLabel(description, FontSize.SMALL, FontColor.FADED))
        self.setLayout(_main_layout)

    def get_values(self):
        return [self._listbox.item(i).data(Qt.UserRole) for i in range(self._listbox.count())]

    def change_options(self, options: List[T]):
        self._listbox.clear()
        self._combobox.clear()
        for option in options:
            self._combobox.addItem(str(option))

    def hook_change_function(self, function):
        self._combobox.currentTextChanged.connect(function)
