from PySide6.QtWidgets import (QWidget, QLabel, QVBoxLayout)
from PySide6.QtGui import QFont
from typing import TypeVar

from .enums import FontColor, FontSize

T = TypeVar('T')


class TextLabel(QWidget):
    def __init__(self, label_text: str, font_size: FontSize = FontSize.NORMAL,
                 font_color: FontColor = FontColor.NORMAL):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        label = QLabel(label_text)
        label.setStyleSheet(f"color: {font_color.value}")
        label.setFont(QFont(QFont().defaultFamily(), font_size.value))
        label.setWordWrap(True)
        layout.addWidget(label)

        self.setLayout(layout)


