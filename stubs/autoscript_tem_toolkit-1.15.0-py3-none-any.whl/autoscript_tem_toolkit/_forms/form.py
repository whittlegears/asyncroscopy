from math import ceil
from typing import Optional, Callable, List, TypeVar

from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QFrame,
                               QHBoxLayout, QLabel, QMessageBox, QVBoxLayout)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
import os

from autoscript_tem_microscope_client._structures_shell import Rectangle

from autoscript_tem_microscope_client.structures import Region, EelsExposureSettings
from autoscript_tem_toolkit._forms._simple_inputs.button import Button

from autoscript_tem_toolkit._forms._simple_inputs.checkbox import CheckBox
from autoscript_tem_toolkit._forms._simple_inputs.comboboxes import ComboBox, ListComboBox
from autoscript_tem_toolkit._forms._simple_inputs.number_inputs import FloatInput, IntegerInput
from autoscript_tem_toolkit._forms._structure_inputs.eels_exposure_settings_input import EelsExposureSettingsInput
from autoscript_tem_toolkit._forms._text_label import TextLabel
from autoscript_tem_toolkit._forms.enums import FontColor, FontSize
from autoscript_tem_toolkit._forms._structure_inputs.rectangle_input import RectangleInput
from autoscript_tem_toolkit._forms._structure_inputs.region_input import RegionInput

T = TypeVar('T')


class Form:
    """
    Show a simple form to the user.
    """
    def __init__(self):
        # force light mode (TODO: dark mode support?)
        os.environ["QT_QPA_PLATFORM"] = "windows:darkmode=0"
        self._app = QApplication.instance()
        if self._app is None:
            self._app = QApplication()
        self._window = QWidget()
        self._main_layout = QVBoxLayout(self._window)
        self._columns_layout = QHBoxLayout()
        self._current_layout = QVBoxLayout()
        self._value_callbacks = []
        self._submitted = False

    _WIDGET_WIDTH_FULL = 300
    _WIDGET_WIDTH_HALF = ceil(_WIDGET_WIDTH_FULL / 2)
    _WIDGET_WIDTH_QUARTER = ceil(_WIDGET_WIDTH_FULL / 4)

    def add_column(self):
        """
        Adds a new column to the layout.
        """
        self._columns_layout.addLayout(self._current_layout)
        self._current_layout = QVBoxLayout()

    def add_text_label(self, label_text: str, font_size: FontSize = FontSize.NORMAL, font_color: FontColor = FontColor.NORMAL):
        """
        Adds a text label to the layout.

        :param label_text: The text to be displayed in the label.
        :param font_size: The font size of the text.
        :param font_color: The color of the text.
        """
        label = TextLabel(label_text, font_size, font_color)

        self._current_layout.addWidget(label)

        return label

    def add_button(self, name: str, function: Callable[[], T]):
        button = Button(name, function)

        self._current_layout.addWidget(button)

        return button

    def add_hr(self, description: str = ""):
        """
        Adds a horizontal line to the layout.

        :param description: The description of the input.
        """
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFixedWidth(self._WIDGET_WIDTH_FULL)
        line.setStyleSheet("color: grey;")

        self._current_layout.addWidget(line)

        if description !="":
            self.add_text_label(description, FontSize.SMALL, FontColor.FADED)

        return line

    def add_integer_input(self, label_text: str, value_callback: Callable[[Optional[float]], None], default_value: int = 0.0,
                          description: str = "", minimum: int = 0, maximum: int = 1000000, step: int = 1, special_value_text: str = None):
        """
        Adds an integer input to the layout.

        :param label_text: The text to be displayed as a label for the input.
        :param value_callback: Function that will be called with the value of the input.
        :param default_value: The default value to be displayed in the input.
        :param description: The description of the input.
        :param minimum: The minimum value of the input.
        :param maximum: The maximum value of the input.
        :param step: The step for the arrows of the input
        :param special_value_text: A string displayed instead of the minimum value
        """
        integer_input = IntegerInput(label_text, description, default_value, minimum, maximum, step, special_value_text)

        def integer_input_callback():
            value_callback(integer_input.get_value())

        self._value_callbacks.append(integer_input_callback)
        self._current_layout.addWidget(integer_input)

        return integer_input

    def add_float_input(self, label_text: str, value_callback: Callable[[Optional[float]], None], default_value: float = 0.0,
                        description: str = ""):
        """
        Adds a float input to the layout.

        :param label_text: The text to be displayed as a label for the input.
        :param value_callback: Function that will be called with the value of the input.
        :param default_value: The default value to be displayed in the input.
        :param description: The description of the input.
        """
        float_input = FloatInput(label_text, description, default_value)

        def float_input_callback():
            value_callback(float_input.get_value())

        self._value_callbacks.append(float_input_callback)
        self._current_layout.addWidget(float_input)

        return float_input

    def add_checkbox(self, label_text: str, value_callback: Callable[[Optional[bool]], None], default_value: Optional[bool] = None, description: str = ""):
        """
        Adds a checkbox to the layout.

        :param label_text: The text to be displayed as a label for the checkbox.
        :param value_callback: Function that will be called with the value of checkbox.
        :param default_value: The default value of the checkbox.
        :param description: The description of the input.
        """
        checkbox = CheckBox(label_text, default_value, description)

        def checkbox_callback():
            value_callback(checkbox.get_state())

        self._value_callbacks.append(checkbox_callback)
        self._current_layout.addWidget(checkbox)

        return checkbox

    def add_combobox(self, label_text: str, value_callback: Callable[[Optional[T]], None], options: List[T], is_editable: bool = False,
                     description: str = ""):
        """
        Adds a combobox to the layout.

        :param label_text: The text to be displayed as a label for the combobox.
        :param value_callback: Function that will be called with the value of the combobox.
        :param options: The list of options for the combobox.
        :param is_editable: True if the combobox is editable, False otherwise.
        :param description: The description of the input.
        """
        combobox = ComboBox(label_text, options, is_editable, description)

        def combobox_callback():
            value_callback(combobox.get_value())

        self._value_callbacks.append(combobox_callback)
        self._current_layout.addWidget(combobox)

        return combobox

    def add_list_combobox(self, label_text: str, value_callback: Callable[[List[T]], None], options: List[T], is_editable: bool = False,
                          description: str = ""):
        list_combobox = ListComboBox(label_text, options, is_editable, description)

        def list_combobox_callback():
            value_callback(list_combobox.get_values())

        self._value_callbacks.append(list_combobox_callback)
        self._current_layout.addWidget(list_combobox)

        return list_combobox

    def add_rectangle_input(self, label_text: str, value_callback: Callable[[Optional[Rectangle]], None], default_value: float = None, description: str = ""):
        rectangle_input = RectangleInput(label_text)

        def rectangle_callback():
            value_callback(rectangle_input.get_value())

        self._value_callbacks.append(rectangle_callback)
        self._current_layout.addWidget(rectangle_input)

        return rectangle_input

    def add_region_input(self, label_text: str, value_callback: Callable[[Optional[Region]], None], default_value: float = None, description: str = ""):
        region_input = RegionInput(label_text)

        def region_callback():
            value_callback(region_input.get_value())

        self._value_callbacks.append(region_callback)
        self._current_layout.addWidget(region_input)

        return region_input

    def add_eels_exposure_settings_input(self, label_text: str, value_callback: Callable[[Optional[EelsExposureSettings]], None]):
        input = EelsExposureSettingsInput(label_text)

        def callback():
            value_callback(input.get_value())

        self._value_callbacks.append(callback)
        self._current_layout.addWidget(input)

    def add_widget(self, widget: QWidget):
        self._current_layout.addWidget(widget)

    def _submit(self):
        """
        Submits the form.
        """
        try:
            for callback in self._value_callbacks:
                callback()
        except Exception as e:
            QMessageBox.critical(self._window, "Error", str(e))
            return

        self._submitted = True
        self._app.quit()

    def _cancel(self):
        """
        Cancels the form.
        """
        self._app.quit()

    def run(self, window_title: str, footer: bool = True, submit_button_text: str = "Submit", cancel_button_text: str = "Cancel") -> bool:
        """
        Runs (shows) the form.

        :param window_title: The title of the window.
        :param submit_button_text: The text to be displayed on the submit button.
        :param cancel_button_text: The text to be displayed on the cancel button.
        :return: True if the form has been submitted, False otherwise.
        """

        if self._current_layout.count() > 0:
            self._columns_layout.addLayout(self._current_layout)

        # Ensure items in columns are stacked at the top
        for i in range(self._columns_layout.count()):
            column = self._columns_layout.itemAt(i)
            column.addStretch()

        self._main_layout.addLayout(self._columns_layout)

        footer_layout = QHBoxLayout()

        if footer:
            btn_submit = QPushButton(submit_button_text)
            btn_submit.clicked.connect(self._submit)
            btn_submit.setFixedWidth(self._WIDGET_WIDTH_QUARTER)
            footer_layout.addWidget(btn_submit, alignment=Qt.AlignTop)

            btn_cancel = QPushButton(cancel_button_text)
            btn_cancel.clicked.connect(self._cancel)
            btn_cancel.setFixedWidth(self._WIDGET_WIDTH_QUARTER)
            footer_layout.addWidget(btn_cancel, alignment=Qt.AlignTop)
            footer_layout.addStretch()


            line = QFrame()
            line.setFrameShape(QFrame.HLine)
            line.setStyleSheet("color: grey;")
            self._main_layout.addWidget(line)

            self._main_layout.addLayout(footer_layout)

        self._window.setWindowTitle(window_title)
        self._window.show()
        self._app.exec()

        return self._submitted
