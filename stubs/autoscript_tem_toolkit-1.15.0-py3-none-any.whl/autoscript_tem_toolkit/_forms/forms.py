from typing import List, Tuple, Dict, Optional

from autoscript_tem_microscope_client.enumerations import *
from autoscript_tem_microscope_client.structures import *
from autoscript_tem_microscope_client.structures import CameraAcquisitionSettings, StemDataSettings, StemAcquisitionSettings
from .form import Form
from .lens_table import LensTable

def _get_all_scanning_detector_segment_combinations(microscope) -> List[Tuple[str, str]]:
    segments = []

    for detector_name in microscope.detectors.scanning_detectors:
        detector = microscope.detectors.get_scanning_detector(detector_name)

        for segment in detector.get_segments():
            segments.append((detector.name, segment.name))

    return segments


def _get_all_eds_detector_segment_combinations(microscope) -> List[Tuple[str, str]]:
    segments = []

    for detector_name in microscope.detectors.eds_detectors:
        detector = microscope.detectors.get_eds_detector(detector_name)

        for segment in detector.get_segments():
            segments.append((detector.name, segment.name))
    return segments


def _flatten_detector_segment_combinations(detector_segment_combinations: List[Tuple[str, str]]) -> Dict[str, List[str]]:
    detector_segments = {}

    for detector_name, segment_name in detector_segment_combinations:
        if detector_name not in detector_segments:
            detector_segments[detector_name] = []

        detector_segments[detector_name].append(segment_name)
    return detector_segments


def create_stem_acquisition_settings(microscope) -> StemAcquisitionSettings | None:
    form = Form()
    settings = StemAcquisitionSettings()

    def set_dwell_time(value):
        settings.dwell_time = value

    form.add_float_input("Dwell time (s)", set_dwell_time)

    def set_size(value):
        if value == 0:
            settings.size = None
        else:
            settings.size = value

    form.add_integer_input("Size (pixels)", set_size, step=128)

    def set_auto_beam_blank(value: bool):
        settings.auto_beam_blank = value

    form.add_checkbox("Auto beam blank", set_auto_beam_blank)

    def set_region(value: Region):
        if value.rectangle.width == 0 or value.rectangle.height == 0:
            settings.region = None
        else:
            settings.region = value

    form.add_region_input("Region", set_region)

    form.add_column()

    def set_detector_types(values: List[str]):
        settings.detector_types = values

    form.add_list_combobox("Detector types", set_detector_types, microscope.detectors.scanning_detectors,
                           description="Select the detector types to be used for the acquisition.")

    def set_detector_segments(values: List[Tuple[str, str]]):
        for detector_name, segment_names in _flatten_detector_segment_combinations(values).items():
            detector = microscope.detectors.get_scanning_detector(detector_name)
            detector.set_enabled_segments(segment_names)

            if settings.detector_segments is None:
                settings.detector_segments = []

            for segment in detector.get_enabled_segments():
                settings.detector_segments.append(segment)

    detector_segment_combinations = _get_all_scanning_detector_segment_combinations(microscope)
    form.add_list_combobox("Detector segments", set_detector_segments, detector_segment_combinations, is_editable=False,
                           description="Select the detector-segments combinations to be used for the acquisition.")

    if form.run("Stem Acquisition Settings"):
        return settings

def create_stem_data_settings(microscope) -> StemDataSettings | None:
    form = Form()
    settings = StemDataSettings()

    def set_dwell_time(value):
        settings.dwell_time = value

    form.add_float_input("Dwell time (s)", set_dwell_time)

    def set_size(value):
        if value == 0:
            settings.size = None
        else:
            settings.size = value

    form.add_integer_input("Size (pixels)", set_size, step=128)

    def set_detector_types(values: List[str]):
        settings.detector_types = values

    form.add_list_combobox("Detector types", set_detector_types, microscope.detectors.scanning_detectors,
                           description="Select the detector types to be used for the acquisition.")

    def set_region(value: Region):
        if value.rectangle.width == 0 or value.rectangle.height == 0:
            settings.region = None
        else:
            settings.region = value

    form.add_region_input("Region", set_region)


    if form.run("Stem Data Settings"):
        return settings


def create_camera_acquisition_settings(microscope) -> CameraAcquisitionSettings | None:
    form = Form()
    settings = CameraAcquisitionSettings()

    def set_camera_detector(value):
        settings.camera_detector = value

    form.add_combobox("Camera detector", set_camera_detector, microscope.detectors.camera_detectors)

    def set_size(value):
        settings.size = value

    form.add_integer_input("Size (pixels)", set_size, step=128)

    def set_exposure_time(value):
        settings.exposure_time = value

    form.add_integer_input("Exposure time (s)", set_exposure_time)

    def set_fixed_readout_area(value):
        settings.fixed_readout_area = value

    form.add_combobox("Fixed readout area", set_fixed_readout_area, FixedReadoutArea.get_all_items())

    def set_electron_counting(value):
        settings.electron_counting = value

    form.add_checkbox("Electron counting", set_electron_counting)

    def set_frame_combining(value):
        if value == 0:
            settings.frame_combining = None
        else:
            settings.frame_combining = value

    form.add_integer_input("Frame combining", set_frame_combining, description="Must be None unless a Ceta camera is chosen", special_value_text="None")

    if form.run("Camera Acquisition Settings"):
        return settings


def create_eds_acquisition_settings(microscope) -> EdsAcquisitionSettings | None:
    form = Form()
    settings = EdsAcquisitionSettings()

    def set_eds_detector(value):
        settings.eds_detector = value

    eds_detector = form.add_combobox("Eds detector", set_eds_detector, microscope.detectors.eds_detectors)

    def set_dispersion(value):
        settings.dispersion = float(value)

    dispersion = form.add_combobox("Dispersion (eV)", set_dispersion, [])

    def set_shaping_time(value):
        settings.shaping_time = float(value)

    shaping = form.add_combobox("Shaping time (s)", set_shaping_time, [])

    def set_exposure_time(value):
        settings.exposure_time = value

    form.add_float_input("Exposure time (s)", set_exposure_time)

    def set_exposure_time_type(value):
        settings.exposure_time_type = value

    form.add_combobox("Exposure time type", set_exposure_time_type, ExposureTimeType.get_all_items())

    def set_detector_segments(values: List[Tuple[str, str]]):
        for detector_name, segment_names in _flatten_detector_segment_combinations(values).items():
            detector = microscope.detectors.get_eds_detector(detector_name)
            detector.set_enabled_segments(segment_names)

            if settings.detector_segments is None:
                settings.detector_segments = []

            for segment in detector.get_enabled_segments():
                settings.detector_segments.append(segment)

    detector_segment_combinations = _get_all_eds_detector_segment_combinations(microscope)
    form.add_list_combobox("Detector segments", set_detector_segments, detector_segment_combinations,
                           description="Select the detector-segments combinations to be used for the acquisition.")

    def fetch_detector_values():
        detector = microscope.detectors.get_eds_detector(eds_detector.get_value())
        dispersion.change_options([str(x) for x in detector.dispersions])
        shaping.change_options([str(x) for x in detector.shaping_times])

    fetch_detector_values()
    eds_detector.hook_change_function(fetch_detector_values)

    if form.run("Eds Acquisition Settings"):
        return settings

def create_eds_spectrum_image_settings(microscope) -> EdsSpectrumImageSettings | None:
    form = Form()
    settings = EdsSpectrumImageSettings()

    def set_eds_detector(value):
        settings.eds_detector = value

    eds_detector = form.add_combobox("Eds detector", set_eds_detector, microscope.detectors.eds_detectors)

    def set_dispersion(value):
        settings.dispersion = float(value)

    dispersion = form.add_combobox("Dispersion (eV)", set_dispersion, [])

    def set_shaping_time(value):
        settings.shaping_time = float(value)

    shaping = form.add_combobox("Shaping time (s)", set_shaping_time, [])

    def set_dwell_time(value):
        settings.dwell_time = value

    form.add_float_input("Dwell time (s)", set_dwell_time)

    def set_eds_event_stream(value):
        settings.save_eds_event_stream = value

    form.add_checkbox("Save EDS event stream", set_eds_event_stream)

    def fetch_detector_values():
        detector = microscope.detectors.get_eds_detector(eds_detector.get_value())
        dispersion.change_options([str(x) for x in detector.dispersions])
        shaping.change_options([str(x) for x in detector.shaping_times])

    fetch_detector_values()
    eds_detector.hook_change_function(fetch_detector_values)

    def set_size(value):
        settings.size = value

    form.add_integer_input("Size (pixels)", set_size, step=128)

    def set_region(value):
        settings.region = value

    form.add_region_input("Region", set_region)

    form.add_column()

    def set_eds_detector_segments(values: List[Tuple[str, str]]):
        for detector_name, segment_names in _flatten_detector_segment_combinations(values).items():
            detector = microscope.detectors.get_eds_detector(detector_name)
            detector.set_enabled_segments(segment_names)

            if settings.eds_detector_segments is None:
                settings.eds_detector_segments = []

            for segment in detector.get_enabled_segments():
                settings.eds_detector_segments.append(segment)

    eds_detector_segment_combinations = _get_all_eds_detector_segment_combinations(microscope)
    form.add_list_combobox("Eds Detector segments", set_eds_detector_segments, eds_detector_segment_combinations)

    def set_scanning_detectors(values: List[str]):
        settings.scanning_detectors = values

    form.add_list_combobox("Scanning detectors", set_scanning_detectors, microscope.detectors.scanning_detectors)

    def set_scanning_detector_segments(values: List[Tuple[str, str]]):
        for detector_name, segment_names in _flatten_detector_segment_combinations(values).items():
            detector = microscope.detectors.get_scanning_detector(detector_name)
            detector.set_enabled_segments(segment_names)

            if settings.scanning_detector_segments is None:
                settings.scanning_detector_segments = []

            for segment in detector.get_enabled_segments():
                settings.scanning_detector_segments.append(segment)

    scanning_detector_segment_combinations = _get_all_scanning_detector_segment_combinations(microscope)
    form.add_list_combobox("Scanning Detector segments", set_scanning_detector_segments, scanning_detector_segment_combinations)

    if form.run("Eds Spectrum Image Settings"):
        return settings

def free_lens_control(microscope):
    form = Form()
    lens_control = LensTable(microscope, 4)
    form.add_widget(lens_control)

    form.run("Free lens control", footer=False)
