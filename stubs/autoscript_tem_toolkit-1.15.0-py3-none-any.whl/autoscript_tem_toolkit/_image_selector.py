import math
import matplotlib.pyplot as plot

from matplotlib.widgets import RectangleSelector
from typing import List

from autoscript_tem_microscope_client.enumerations import RegionCoordinateSystem
from autoscript_tem_microscope_client.structures import Point, Rectangle, AdornedImage


def select_points(image: AdornedImage, plot_label: str, close_on_first: bool) -> List[Point]:
    selected_points = []

    def button_press_handler(event):
        selected_points.append(Point(x=int(event.xdata), y=int(event.ydata)))

        if close_on_first:
            plot.close()

    plot.figure(0)
    plot.suptitle(plot_label)
    plot.imshow(image.data, cmap="gray")

    plot_figure = plot.figure(0)
    event_id = plot_figure.canvas.mpl_connect("button_press_event", button_press_handler)
    plot.show()
    plot_figure.canvas.mpl_disconnect(event_id)

    return selected_points


def select_rectangles(image: AdornedImage, coordinate_system: str, plot_label: str,
                      close_on_first: bool) -> List[Rectangle]:
    selected_areas = []

    def line_select_callback(click, release):
        def to_relative(value, size):
            return math.floor(100 * (value / size)) / 100

        x1, y1 = click.xdata, click.ydata
        x2, y2 = release.xdata, release.ydata

        if coordinate_system == RegionCoordinateSystem.RELATIVE:
            selected_area = Rectangle(to_relative(x1, image.width), to_relative(y1, image.height),
                                      to_relative(x2 - x1, image.width), to_relative(y2 - y1, image.height))
        else:
            selected_area = Rectangle(int(x1), int(y1), int(x2 - x1), int(y2 - y1))

        selected_areas.append(selected_area)

        if close_on_first:
            plot.close()

    plot_figure, plot_axes = plot.subplots()
    _ = RectangleSelector(plot_axes,
                          line_select_callback,
                          minspanx=5,
                          minspany=5,
                          useblit=True,
                          spancoords="pixels",
                          button=[1, 3])  # don't use middle button

    plot.suptitle(plot_label)
    plot.imshow(image.data, cmap="gray")
    plot.show()

    return selected_areas
