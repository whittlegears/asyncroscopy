from typing import Union
from contextlib import contextmanager

from autoscript_tem_microscope_client.tem_microscope._optics import Optics
from autoscript_tem_microscope_client.tem_microscope.detectors._screen import Screen
from autoscript_tem_microscope_client.tem_microscope.optics._blanker import Blanker
from autoscript_tem_microscope_client.tem_microscope.optics.blanker.auto_beam_blank._mode import Mode
from autoscript_tem_microscope_client.tem_microscope.optics.energy_filter._slit import Slit
from autoscript_tem_microscope_client.tem_microscope.optics.blanker._beam_modulator import BeamModulator
from autoscript_tem_microscope_client._dynamic_object_proxies import CameraDetector, EdsDetector, ScanningDetector, ApertureMechanism
from autoscript_tem_microscope_client.enumerations import ScreenPosition, AutoBeamBlankMode

__all__ = ["insert_context", "retract_context", "blanker_context", "auto_beam_blank_mode_context", "beam_modulator_context"]


@contextmanager
def insert_context(insertable: Union[CameraDetector, EdsDetector, ScanningDetector, Slit, Screen, ApertureMechanism]) -> None:
    """
    The insert context manager positions the given mechanism inside the microscope by calling insert() and
    retracts it again by calling retract().
    """
    try:
        if hasattr(insertable, "is_insertable") and insertable.is_insertable or \
                hasattr(insertable, "is_retractable") and insertable.is_retractable or \
                hasattr(insertable, "is_inserted") and not insertable.is_inserted or \
                hasattr(insertable, "position") and insertable.position == ScreenPosition.RETRACTED:
            insertable.insert()

        yield

    finally:
        insertable.retract()


@contextmanager
def retract_context(retractable: Union[CameraDetector, EdsDetector, ScanningDetector, Slit, Screen, ApertureMechanism]) -> None:
    """
    The retract context manager withdraws the given mechanism from the microscope by calling retract() and
    inserts it again by calling insert().
    """
    try:
        if hasattr(retractable, "is_insertable") and retractable.is_insertable or \
                hasattr(retractable, "is_retractable") and retractable.is_retractable or \
                hasattr(retractable, "is_inserted") and retractable.is_inserted or \
                hasattr(retractable, "position") and retractable.position == ScreenPosition.INSERTED:
            retractable.retract()

        yield

    finally:
        retractable.insert()


@contextmanager
def blanker_context(blanker: [Blanker | Optics]) -> None:
    """
    Unblanks the beam blanker inside the with block by calling unblank() and blanks it using blank()
    upon exit from the with block.
    """
    try:
        blanker.unblank()
        yield

    finally:
        blanker.blank()


@contextmanager
def auto_beam_blank_mode_context(auto_beam_blank_mode: Mode, mode: AutoBeamBlankMode) -> None:
    """
    Sets the provided auto beam blank mode, resets it back to the default mode afterwards.
    """
    try:
        auto_beam_blank_mode.value = mode
        yield

    finally:
        auto_beam_blank_mode.reset_to_default()


@contextmanager
def beam_modulator_context(beam_modulator: BeamModulator, duty_cycle: float = None, frequency: float = None) -> None:
    """
    Starts the beam modulator inside the with block by calling start_modulation(duty_cycle, frequency) and stops it using stop_modulation()
    upon exit from the with block.
    """
    try:
        beam_modulator.start_modulation(duty_cycle, frequency)
        yield

    finally:
        beam_modulator.stop_modulation()