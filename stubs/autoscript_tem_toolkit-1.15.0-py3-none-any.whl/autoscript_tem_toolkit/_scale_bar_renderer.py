import math
import string
import PIL.ImageDraw as PilDraw
import PIL.ImageFont as PilFont
from typing import NamedTuple

from ._draw_utilities import DrawColors, scale_sizes
from autoscript_tem_microscope_client.structures import AdornedImageMetadata


def draw_scale_bar(pil_draw: PilDraw, image_width: int, image_height: int, metadata: AdornedImageMetadata,
                   colors: DrawColors) -> PilDraw:
    """
    Draws a scale bar on the given pil draw object.
    """

    text, line_width = _get_properties(image_width, metadata)
    sizes = scale_sizes(image_height, _default_sizes)
    bar_color = colors.light_color
    outline_color = colors.dark_color

    # Draw a line with an outline
    line_start = (sizes.margin, image_height - sizes.line_top)
    line_end = (line_width + sizes.margin, image_height - sizes.line_top)
    outline_start = (line_start[0] - sizes.outline_width, line_start[1])
    outline_end = (line_end[0] + sizes.outline_width, line_end[1])
    pil_draw.line(outline_start + outline_end, outline_color, sizes.line_thickness + sizes.outline_width * 2)
    pil_draw.line(line_start + line_end, bar_color, sizes.line_thickness)

    # Draw text with an outline: stroke
    text_origin = (sizes.margin, image_height - sizes.text_top - sizes.margin)
    font = PilFont.truetype("arial.ttf", sizes.text_size)
    pil_draw.text(text_origin, text, bar_color, font, stroke_fill=outline_color,
                  stroke_width=sizes.outline_width)


class _Sizes(NamedTuple):
    margin: int
    line_thickness: int
    line_top: int
    text_top: int
    text_size: int
    outline_width: int


# Default sizes are for an image with a height equal to min_image_size
_default_sizes = _Sizes(margin=4, line_thickness=1, line_top=4, text_top=18, text_size=12, outline_width=1)


_min_ratio = 6


def _get_properties(image_width: int, metadata: AdornedImageMetadata) -> (str, int):
    pixel_width, unit, unit_power = _get_pixel_info_from_metadata(metadata)

    min_bar_width = int(image_width / _min_ratio)
    min_bar_width_in_unit = min_bar_width * pixel_width

    nice_value_for_print, nice_value, prefix = _get_nice_value_with_prefix(min_bar_width_in_unit, unit_power)
    line_width_in_pixels = int(nice_value / pixel_width)

    text = f"{nice_value_for_print} {prefix}{unit}"

    if unit_power != 1:
        text = text + _get_number_as_superscript(unit_power)

    return text, line_width_in_pixels


def _get_number_as_superscript(number: int) -> str:
    result = ""

    if number < 0:
        result += chr(0x02c9)
        number = abs(number)

    for digit in map(int, str(number)):
        if digit == 1:
            result += chr(0x00b9)
        elif 2 <= digit <= 3:
            result += chr(0x00b0 + digit)
        else:
            result += chr(0x2070 + digit)

    return result


def _get_pixel_info_from_metadata(metadata: AdornedImageMetadata) -> (float, str, int):
    binary_result = None
    pixel_width = None
    unit = "m"
    unit_power = 1

    def raise_value_error():
        raise ValueError("Metadata doesn't contain pixel size.")

    try:
        binary_result = metadata.binary_result
        pixel_width = binary_result.pixel_size.x

        if pixel_width is None:
            raise_value_error()

        if pixel_width <= 0:
            raise ValueError("Pixel size metadata value is invalid.")
    except AttributeError:
        # Attribute error means that necessary metadata are not available
        raise_value_error()

    try:
        if binary_result.pixel_size_x_unit.name is not None:
            # Sometimes the exponent is part of the unit name, so we filter out non-ascii letter characters from it
            unit = _filter_out_non_ascii_letters(binary_result.pixel_size_x_unit.name)
        if binary_result.pixel_size_x_unit.prefix_power is not None:
            unit_power = binary_result.pixel_size_x_unit.prefix_power
    except AttributeError:
        # Attribute error means that non-necessary metadata are not available, ignore this
        pass

    return pixel_width, unit, unit_power


def _filter_out_non_ascii_letters(value: str) -> str:
    filtered_iterable = filter(lambda x: x in string.ascii_letters, value)
    return "".join(filtered_iterable)


_unit_prefixes = {-12: "p", -9: "n", -6: "µ", -3: "m", 1: "", 3: "k", 6: "M", 9: "G", 12: "T"}


def _get_nice_value_with_prefix(value: float, unit_power: int) -> (float, int, str):
    nice_value = _round_to_nice_value(value)
    decade = _get_decade(nice_value)
    prefix_decade = math.floor(decade / 3) * 3 * unit_power

    if prefix_decade not in _unit_prefixes:
        raise ValueError(f"Prefix for value {value} is not supported.")

    prefix = _unit_prefixes[prefix_decade]
    nice_value_for_print = round(nice_value / pow(10, prefix_decade // unit_power))

    return nice_value_for_print, nice_value, prefix


def _round_to_nice_value(value: float) -> float:
    decade = _get_decade(value)
    power = pow(10, decade)
    value = value / power

    if value <= 2:
        return 2 * power
    elif value <= 5:
        return 5 * power
    else:
        return 10 * power


def _get_decade(value: float) -> int:
    return math.floor(math.log10(value))
