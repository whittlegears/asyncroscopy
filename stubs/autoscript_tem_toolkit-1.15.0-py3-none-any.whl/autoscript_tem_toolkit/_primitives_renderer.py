import numpy
import cv2

from typing import NamedTuple

from ._draw_utilities import scale_sizes, PointLike, RectangleLike, DrawColors


def draw_point(image_data: numpy.ndarray, point: PointLike, image_width: int, image_height: int, colors: DrawColors):
    if point[0] < 0 or point[1] < 0 or point[0] > image_width or point[1] > image_height:
        raise ValueError("Point must be inside the image.")

    sizes = scale_sizes(max(image_width, image_height), _default_point_sizes)
    line_half_length = sizes.line_length // 2
    outline_half_length = sizes.outline_length // 2

    # Draw outlines: horizontal and vertical
    cv2.line(image_data, (point[0] - outline_half_length, point[1]), (point[0] + outline_half_length, point[1]),
             colors.light_color, sizes.outline_thickness)
    cv2.line(image_data, (point[0], point[1] - outline_half_length), (point[0], point[1] + outline_half_length),
             colors.light_color, sizes.outline_thickness)

    # Draw lines: horizontal and vertical
    cv2.line(image_data, (point[0] - line_half_length, point[1]), (point[0] + line_half_length, point[1]),
             colors.dark_color, sizes.line_thickness)
    cv2.line(image_data, (point[0], point[1] - line_half_length), (point[0], point[1] + line_half_length),
             colors.dark_color, sizes.line_thickness)


class _PointSizes(NamedTuple):
    line_thickness: int
    line_length: int
    outline_thickness: int
    outline_length: int


# Default sizes are for an image with a minimum size
_default_point_sizes = _PointSizes(line_thickness=1, line_length=7, outline_thickness=3, outline_length=9)


def draw_rectangle(image_data: numpy.ndarray, rectangle: RectangleLike,
                   image_width: int, image_height: int, colors: DrawColors):
    if rectangle[0] < 0 or rectangle[1] < 0 or \
            rectangle[0] + rectangle[2] > image_width or rectangle[1] + rectangle[3] > image_height:
        raise ValueError("Rectangle must be inside the image.")

    if rectangle[2] <= 0 or rectangle[3] <= 0:
        raise ValueError("Rectangle can't have zero size in both dimensions.")

    sizes = scale_sizes(max(image_width, image_height), _default_rectangle_sizes)

    # Draw rectangle: outline and line
    cv2.rectangle(image_data, (rectangle[0], rectangle[1]), (rectangle[0] + rectangle[2], rectangle[1] + rectangle[3]),
                  color=colors.light_color, thickness=sizes.outline_thickness)
    cv2.rectangle(image_data, (rectangle[0], rectangle[1]), (rectangle[0] + rectangle[2], rectangle[1] + rectangle[3]),
                  color=colors.dark_color, thickness=sizes.line_thickness)


class _RectangleSizes(NamedTuple):
    line_thickness: int
    outline_thickness: int


_default_rectangle_sizes = _RectangleSizes(line_thickness=1, outline_thickness=3)
