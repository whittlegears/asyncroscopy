import os
import contextlib
import importlib.util
import shutil
import tempfile
from unittest.mock import MagicMock

from autoscript_tem_microscope_client.enumerations import DetectorType
from autoscript_tem_microscope_client.structures import StemAcquisitionSettings
from matplotlib import pyplot as plot
import autoscript_tem_toolkit.vision as vision_toolkit
import autoscript_tem_toolkit.user_interface as ui_toolkit
from autoscript_core.common import ApplicationServerException
from autoscript_tem_microscope_client_tests.base.microscope_test_case import MicroscopeTestCase
from autoscript_tem_microscope_client_tests.utilities import eligibility_utilities as eligibility


class SnippetTests(MicroscopeTestCase):
    # Path to Snippets when run from this file
    _snippets_directory = "..\\..\\Documentation\\CodeSnippets"

    # Path to Snippets when run from the pipeline tests
    _snippets_directory_build = "..\\..\\Sources\\Documentation\\CodeSnippets"

    # Name of the directory in Temp where backups are stored (and which snippets use for saving files)
    _tempdir_name = "AutoScriptTEM"

    @eligibility.is_offline()
    def test_snippets(self):
        if os.path.exists(self._snippets_directory):
            path_to_snippets = self._snippets_directory
        else:
            path_to_snippets = self._snippets_directory_build

        # change the path to snippets from a relative path to an absolute one to avoid future chdir problems with snippets
        path_to_snippets = os.path.join(os.getcwd(), path_to_snippets)

        self._mock_ui_functions()
        self._set_up_temp_files_folder()

        self._backup_example_files(path_to_snippets)

        try:
            self._import_and_run_py_files(path_to_snippets)
        finally:
            self._restore_example_files(path_to_snippets)

        print("All snippets executed successfully")

    def _import_and_run_py_files(self, directory):
        print(directory)
        files = os.listdir(directory)

        if len(files) == 0:
            raise AssertionError("Snippets folder is empty")

        for filename in files:
            file_path = os.path.join(directory, filename)

            if os.path.isdir(file_path):
                self._import_and_run_py_files(file_path)

            elif filename.endswith(".py"):
                module_name = os.path.splitext(filename)[0]

                spec = importlib.util.spec_from_file_location(module_name, file_path)

                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    try:
                        os.chdir(os.path.join(file_path, ".."))

                        # suppress print output from snippets
                        with contextlib.redirect_stdout(None):
                            spec.loader.exec_module(module)

                        print(f"Snippet {module_name} executed successfully")

                    except Exception as e:
                        self._handle_exception(filename, e)

                else:
                    raise Exception("Could not load {filename}")

    # ApplicationServerExceptions are ignored
    @staticmethod
    def _handle_exception(filename, e):
        if isinstance(e, ApplicationServerException):
            return

        raise AssertionError(f"Snippet {filename} failed with exception: {e}")

    # To prevent UI from blocking the thread during testing
    @staticmethod
    def _mock_ui_functions():
        plot.imshow = MagicMock()
        plot.show = MagicMock()

        # If we choose to include more form snippets, we might have to figure out a better way to do this
        stem_acquisition_mock = MagicMock()
        stem_acquisition_settings = StemAcquisitionSettings(dwell_time=1, size=512, detector_types=[DetectorType.BF])
        stem_acquisition_mock.return_value = stem_acquisition_settings
        ui_toolkit.create_stem_acquisition_settings = stem_acquisition_mock

    #  Remove all files in the AutoScriptTEM tmp folder, or create it if it didn't exist
    def _set_up_temp_files_folder(self):
        tmp_directory = os.path.join(tempfile.gettempdir(), self._tempdir_name)

        try:
            if not os.path.exists(tmp_directory):
                os.mkdir(tmp_directory)

            else:
                shutil.rmtree(tmp_directory)
                os.mkdir(tmp_directory)

        except Exception as e:
            raise Exception(f"Failed to set up tmp folder: {e}")

    def _backup_example_files(self, path_to_snippets):
        tmp_directory = os.path.join(tempfile.gettempdir(), self._tempdir_name, "backup")
        source_directory = os.path.join(path_to_snippets, "example_files")
        shutil.copytree(source_directory, tmp_directory, dirs_exist_ok=True)

    def _restore_example_files(self, path_to_snippets):
        tmp_directory = os.path.join(tempfile.gettempdir(), self._tempdir_name, "backup")
        source_directory = os.path.join(path_to_snippets, "example_files")
        shutil.copytree(tmp_directory, source_directory, dirs_exist_ok=True)
