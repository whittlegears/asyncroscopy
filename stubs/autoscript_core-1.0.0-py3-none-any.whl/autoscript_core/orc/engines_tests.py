import unittest

from autoscript_core.orc.engines import EndpointState
from autoscript_core.common import TransportEndpointDefinition
from autoscript_core.framed_transport import FrameSocketException
from autoscript_core.orc import ClientEndpoint, EndpointException, EndpointExceptionCause


class FakeCannotConnectClientFrameSocket:
    def connect(self, server_transport_endpoint: TransportEndpointDefinition):
        raise FrameSocketException("Cannot connect.")


class TestableCannotConnectClientEndpoint(ClientEndpoint):
    def _create_client_frame_socket(self):
        return FakeCannotConnectClientFrameSocket()


class TestableRunningClientEndpoint(ClientEndpoint):
    def __init__(self):
        super().__init__()

        self._ClientEndpoint__state = EndpointState.RUNNING


class ClientEndpointTests(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test__connect__when_already_running__raises_proper_exception(self):
        client_endpoint = TestableRunningClientEndpoint()
        server_transport_endpoint = TransportEndpointDefinition("127.0.0.1", 7520)

        with self.assertRaises(EndpointException) as context:
            client_endpoint.connect(server_transport_endpoint)

        self.assertEqual(context.exception.cause, EndpointExceptionCause.STATE)

    def test__connect__when_transport_layer_issues_occur__raises_proper_exception(self):
        client_endpoint = TestableCannotConnectClientEndpoint()
        server_transport_endpoint = TransportEndpointDefinition("127.0.0.1", 7520)

        with self.assertRaises(EndpointException) as context:
            client_endpoint.connect(server_transport_endpoint)

        self.assertEqual(context.exception.cause, EndpointExceptionCause.L4_NETWORKING)
