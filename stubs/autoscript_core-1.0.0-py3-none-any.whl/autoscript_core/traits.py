
def traits(*args, **kwargs):
    """
    Empty decorator to mark tests with traits, that are parsed by TestsRunner.
    """
    def wrapper(func):
        return func
    return wrapper